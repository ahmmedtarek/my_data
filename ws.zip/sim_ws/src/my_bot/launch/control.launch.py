import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = 'my_bot'  # Update with your package name

    # Path to the controllers YAML file
    controllers_file = os.path.join(
        get_package_share_directory(package_name),
        'config',
        'ackermann_controllers.yaml'
    )

    # Ensure the parameter file exists
    if not os.path.isfile(controllers_file):
        raise RuntimeError(f"Controller parameter file not found: {controllers_file}")

    # Start the controller manager
    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[controllers_file],
        output='screen'
    )

    # Spawn controllers using the correct path
    spawner_rear_wheel = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['rear_wheel_controller'],
        output='screen'
    )

    spawner_steering = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['steering_controller'],
        output='screen'
    )

    return LaunchDescription([
        controller_manager,
        spawner_rear_wheel,
        spawner_steering
    ])
