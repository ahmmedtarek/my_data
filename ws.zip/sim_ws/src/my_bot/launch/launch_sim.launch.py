import os
import time
from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = 'my_bot'  # Update with your package name

    # Load robot_state_publisher (RSP)
    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory(package_name), 'launch', 'rsp.launch.py')
        ]),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    # Launch Gazebo with the necessary plugins
    gazebo = ExecuteProcess(
        cmd=[
            'gzserver', '--verbose', 
            '-s', 'libgazebo_ros_factory.so'
        ],
        output='screen'
    )

    gzclient = ExecuteProcess(
        cmd=['gzclient'],
        output='screen'
    )

    # Delay spawn_entity to ensure Gazebo is fully started
    spawn_entity = TimerAction(
        period=5.0,  # Wait 5 seconds before spawning the robot
        actions=[Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-topic', 'robot_description', '-entity', 'my_bot'],
            output='screen'
        )]
    )
    return LaunchDescription([
        rsp,
        gazebo,
        gzclient,
        spawn_entity,

    ])
