from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package="controller_manager",
            executable="ros2_control_node",
            parameters=["config/ackermann_controllers.yaml"],
            output="screen",
        ),
        Node(
            package="controller_manager",
            executable="spawner.py",
            arguments=["rear_wheel_controller"],
            output="screen",
        ),
        Node(
            package="controller_manager",
            executable="spawner.py",
            arguments=["steering_controller"],
            output="screen",
        ),
    ])
