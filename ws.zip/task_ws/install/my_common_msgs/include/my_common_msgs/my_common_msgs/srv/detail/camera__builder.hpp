// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_common_msgs:srv/Camera.idl
// generated code does not contain a copyright notice

#ifndef MY_COMMON_MSGS__SRV__DETAIL__CAMERA__BUILDER_HPP_
#define MY_COMMON_MSGS__SRV__DETAIL__CAMERA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_common_msgs/srv/detail/camera__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_common_msgs
{

namespace srv
{

namespace builder
{

class Init_Camera_Request_angle
{
public:
  Init_Camera_Request_angle()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_common_msgs::srv::Camera_Request angle(::my_common_msgs::srv::Camera_Request::_angle_type arg)
  {
    msg_.angle = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_common_msgs::srv::Camera_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_common_msgs::srv::Camera_Request>()
{
  return my_common_msgs::srv::builder::Init_Camera_Request_angle();
}

}  // namespace my_common_msgs


namespace my_common_msgs
{

namespace srv
{

namespace builder
{

class Init_Camera_Response_image
{
public:
  Init_Camera_Response_image()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::my_common_msgs::srv::Camera_Response image(::my_common_msgs::srv::Camera_Response::_image_type arg)
  {
    msg_.image = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_common_msgs::srv::Camera_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_common_msgs::srv::Camera_Response>()
{
  return my_common_msgs::srv::builder::Init_Camera_Response_image();
}

}  // namespace my_common_msgs

#endif  // MY_COMMON_MSGS__SRV__DETAIL__CAMERA__BUILDER_HPP_
