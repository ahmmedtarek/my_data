// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_COMMON_MSGS__SRV__CAMERA_HPP_
#define MY_COMMON_MSGS__SRV__CAMERA_HPP_

#include "my_common_msgs/srv/detail/camera__struct.hpp"
#include "my_common_msgs/srv/detail/camera__builder.hpp"
#include "my_common_msgs/srv/detail/camera__traits.hpp"
#include "my_common_msgs/srv/detail/camera__type_support.hpp"

#endif  // MY_COMMON_MSGS__SRV__CAMERA_HPP_
