// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_common_msgs:srv/Camera.idl
// generated code does not contain a copyright notice

#ifndef MY_COMMON_MSGS__SRV__CAMERA_H_
#define MY_COMMON_MSGS__SRV__CAMERA_H_

#include "my_common_msgs/srv/detail/camera__struct.h"
#include "my_common_msgs/srv/detail/camera__functions.h"
#include "my_common_msgs/srv/detail/camera__type_support.h"

#endif  // MY_COMMON_MSGS__SRV__CAMERA_H_
