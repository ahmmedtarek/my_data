from my_common_msgs.srv._camera import Camera  # noqa: F401
