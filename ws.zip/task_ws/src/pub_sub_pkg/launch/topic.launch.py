from launch import LaunchDescription
from launch_ros.actions import Node
#from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        Node(
            executable="publisher",
            package="pub_sub_pkg",
        ),
        Node(
            executable="subscriber",
            package="pub_sub_pkg",
            parameters=[
                {"rad": 1.0}
            ]
        )

    ])