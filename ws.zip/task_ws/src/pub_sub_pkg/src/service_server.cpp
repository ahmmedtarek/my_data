#include"rclcpp/rclcpp.hpp"
#include"my_common_msgs/srv/camera.hpp"
#include<opencv2/imgcodecs.hpp>
#include<opencv2/highgui.hpp>
#include<cv_bridge/cv_bridge.h>
#include"sensor_msgs/msg/image.hpp"


typedef my_common_msgs::srv::Camera Camera;

class Service_server : public rclcpp::Node
{
    public:
    Service_server() : Node("service_server")
    {
        service_ = this->create_service<Camera>("camera",std::bind(&Service_server::service_CallBack,this,std::placeholders::_1,std::placeholders::_2));

    }

    private:
    void service_CallBack(const Camera::Request::SharedPtr request, const Camera::Response::SharedPtr response)
    {
        auto image = cv::imread("/home/ahmed/Downloads/images/0.jpg");
        std::shared_ptr<sensor_msgs::msg::Image> image_ptr = nullptr;
        switch (request->angle)
        {   
            case 0:
            image = cv::imread("/home/ahmed/Downloads/images/0.png");
            break;

            case 15:
            image = cv::imread("/home/ahmed/Downloads/images/15.png");
            break;

            case 30:
            image = cv::imread("/home/ahmed/Downloads/images/30.png");
            break;

            case -15:
            image = cv::imread("/home/ahmed/Downloads/images/-15.png");
            break;

            case -30:
            image = cv::imread("/home/ahmed/Downloads/images/-30.png");
            break;

            default:
            image = cv::imread("/home/ahmed/Downloads/jinx-graffiti-3840x2160-19975.jpg");
            break;
        }
        cv::imshow("the Image is : ",image);
        cv::waitKey(0);
        image_ptr = cv_bridge::CvImage(std_msgs::msg::Header(),"bgr8",image).toImageMsg();
        response->image = *image_ptr;
    }
    rclcpp::Service<Camera>::SharedPtr service_;

};

int main(int argc, char** argv)
{
    rclcpp::init(argc,argv);
    rclcpp::spin(std::make_shared<Service_server>());
    rclcpp::shutdown();
    return 0;
}