#include "rclcpp/rclcpp.hpp"
#include "my_common_msgs/srv/camera.hpp"
#include<opencv2/imgcodecs.hpp>
#include<opencv2/highgui.hpp>
#include<cv_bridge/cv_bridge.h>
#include"sensor_msgs/msg/image.hpp"
#include <iostream>

typedef my_common_msgs::srv::Camera Camera;

int main(int argc , char* argv[])
{
    rclcpp::init(argc,argv);

    auto node = rclcpp::Node::make_shared("odd_even_check_client");
    auto client = node -> create_client<Camera>("camera");
    auto request = std::make_shared<Camera::Request>();
    
    std::cout<<"Enter the number: ";
    std::cin >> request->angle;

    client->wait_for_service(std::chrono::seconds(5));
    auto result = client ->async_send_request(request);
    if(rclcpp::spin_until_future_complete(node,result) 
    == 
    rclcpp::FutureReturnCode::SUCCESS)
    {
        //auto image_ptr = cv_bridge::toCvCopy(result.get()->image,"bgr8");
        //cv::imshow("the Image is : ",image_ptr->image);
        //cv::waitKey(0);
    }
    else
    {
        std::cout<<"Service call failed"<<std::endl;
    }
    rclcpp::shutdown();
    return 0;
}