#include"rclcpp/rclcpp.hpp"
#include"std_msgs/msg/float64.hpp"

typedef std_msgs::msg::Float64 Float64;

constexpr float CONST_SPEED = 10; 

class Publisher_ : public rclcpp::Node
{
    public:
    Publisher_() : Node("publisher")
    {
        publisher_ = this->create_publisher<Float64>("rpm_topic", 10);
        timer_ = this->create_wall_timer(std::chrono::seconds(1),std::bind(&Publisher_::callBack, this));
    }

    private:
    void callBack(void)
    {
        auto message = Float64();
        message.data = CONST_SPEED;
        this->publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.data);

    }
    rclcpp::Publisher<Float64>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Publisher_>());
    rclcpp::shutdown();
    return 0;
}