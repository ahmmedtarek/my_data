#include"rclcpp/rclcpp.hpp"
#include"std_msgs/msg/float64.hpp"

typedef std_msgs::msg::Float64 Float64;

constexpr double CONST_RAD = 1;

class Subscriber : public rclcpp::Node
{
    public:
    Subscriber() : Node("subscriber")
    {
        this -> declare_parameter("rad",CONST_RAD);
        subscription_ = this->create_subscription<Float64>("rpm_topic",10,std::bind(&Subscriber::callBackSub,this,std::placeholders::_1));
        publisher_ = this->create_publisher<Float64>("Speed_topic",10);

    }
    private:
    void callBackSub(const Float64::SharedPtr msg) const
    {
        RCLCPP_INFO(this->get_logger(), "I heard: '%f'", msg->data);
        rclcpp::Parameter rad = this->get_parameter("rad");
        auto message = Float64();
        double wheel_circumference = 2 * M_PI * rad.as_double();
        auto speed = msg->data * wheel_circumference / 60;
        message.data = speed; 
        this->publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.data);
    }
  
    rclcpp::Subscription<Float64>::SharedPtr subscription_;
    rclcpp::Publisher<Float64>::SharedPtr publisher_;
};

int main(int argc,char* argv[])
{
    rclcpp::init(argc,argv);
    rclcpp::spin(std::make_shared<Subscriber>());
    rclcpp::shutdown();
    return 0;
}