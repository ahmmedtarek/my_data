from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='imu_filter_madgwick',
            executable='imu_filter_madgwick_node',
            name='imu_filter_madgwick',
            output='screen',
            parameters=[{
                'use_mag': False,
                'world_frame': 'enu',
                'publish_tf': False,
                'fixed_frame': 'imu_link'

            }],
            remappings=[
                ('/imu/data_raw', '/my_topic'),   
                ('/imu/mag', '/my_mag'),         
                ('/imu/data', '/imu/data_filtered') 
            ]
        )
    ])
