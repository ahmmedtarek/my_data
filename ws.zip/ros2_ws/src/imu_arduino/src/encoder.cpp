#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <serial_driver/serial_port.hpp>
#include <io_context/io_context.hpp>
#include <sstream>

class SerialEncoderNode : public rclcpp::Node {
public:
    SerialEncoderNode()
    : Node("serial_encoder_node"),
      io_context_(),
      serial_port_(io_context_, "/dev/ttyACM0", get_serial_config()) 
    {
        odom_publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("/wheel_odom", 10);
        serial_port_.open();
        RCLCPP_INFO(this->get_logger(), "Serial port opened successfully.");

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(200),
            std::bind(&SerialEncoderNode::read_from_serial, this)
        );
    }

private:
    drivers::serial_driver::SerialPortConfig get_serial_config() {
        return drivers::serial_driver::SerialPortConfig(
            115200, 
            drivers::serial_driver::FlowControl::NONE, 
            drivers::serial_driver::Parity::NONE, 
            drivers::serial_driver::StopBits::ONE
        );
    }

    void read_from_serial() {
        std::vector<uint8_t> buffer(256);
        size_t bytes_read = serial_port_.receive(buffer);

        if (bytes_read > 0) {
            std::string data(buffer.begin(), buffer.begin() + bytes_read);
            process_serial_data(data);
        }
    }

    void process_serial_data(const std::string &data) {
        std::istringstream stream(data);
        std::string line;
        nav_msgs::msg::Odometry odom_msg;

        while (std::getline(stream, line)) {
            try {
                float linear_velocity = std::stof(line);
                odom_msg.header.stamp = this->now();
                odom_msg.header.frame_id = "odom";
                odom_msg.child_frame_id = "base_link";
                odom_msg.twist.twist.linear.x = linear_velocity;
                odom_msg.twist.twist.angular.z = 0.0; // IMU provides angular velocity

                odom_publisher_->publish(odom_msg);
                RCLCPP_INFO(this->get_logger(), "Published Linear Velocity: %f m/s", linear_velocity);
            } catch (const std::exception &e) {
                RCLCPP_ERROR(this->get_logger(), "Failed to parse encoder data: %s", e.what());
            }
        }
    }
    
    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_publisher_;
    drivers::common::IoContext io_context_;
    drivers::serial_driver::SerialPort serial_port_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SerialEncoderNode>());
    rclcpp::shutdown();
    return 0;
}
