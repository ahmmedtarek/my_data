#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/magnetic_field.hpp>
#include <serial_driver/serial_port.hpp>
#include <io_context/io_context.hpp>
#include <sstream>
#include <vector>

class SerialIMUNode : public rclcpp::Node {
public:
    SerialIMUNode()
    : Node("serial_imu_node"),
      io_context_(),
      serial_port_(io_context_, "/dev/ttyACM0", get_serial_config()) 
    {
        imu_publisher_ = this->create_publisher<sensor_msgs::msg::Imu>("my_topic", 10);
        mag_publisher_ = this->create_publisher<sensor_msgs::msg::MagneticField>("my_mag", 10);

        serial_port_.open();
        RCLCPP_INFO(this->get_logger(), "Serial port opened successfully.");

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500),
            std::bind(&SerialIMUNode::read_from_serial, this)
        );
    }

private:
    drivers::serial_driver::SerialPortConfig get_serial_config() {
        return drivers::serial_driver::SerialPortConfig(
            115200, 
            drivers::serial_driver::FlowControl::NONE, 
            drivers::serial_driver::Parity::NONE, 
            drivers::serial_driver::StopBits::ONE
        );
    }

    void read_from_serial() {
        std::vector<uint8_t> buffer(256);
        size_t bytes_read = serial_port_.receive(buffer);

        if (bytes_read > 0) {
            std::string data(buffer.begin(), buffer.begin() + bytes_read);
            process_serial_data(data);
        }
    }

    void process_serial_data(const std::string &data) {
        std::istringstream stream(data);
        std::string line;
        sensor_msgs::msg::Imu imu_msg;
        sensor_msgs::msg::MagneticField mag_msg;

        while (std::getline(stream, line)) {
            std::vector<std::string> tokens = split(line, ',');
            if (tokens.size() == 9) {  // Ensure all IMU data is received
                try {
                    // Parse accelerometer data (m/s²)
                    imu_msg.linear_acceleration.x = std::stof(tokens[0]);
                    imu_msg.linear_acceleration.y = std::stof(tokens[1]);
                    imu_msg.linear_acceleration.z = std::stof(tokens[2]);

                    // Parse gyroscope data (Convert from °/s to rad/s)
                    imu_msg.angular_velocity.x = std::stof(tokens[3]) ;
                    imu_msg.angular_velocity.y = std::stof(tokens[4]) ;
                    imu_msg.angular_velocity.z = std::stof(tokens[5]) ;

                    // Parse magnetometer data (μT)
                    mag_msg.magnetic_field.x = std::stof(tokens[6]);
                    mag_msg.magnetic_field.y = std::stof(tokens[7]);
                    mag_msg.magnetic_field.z = std::stof(tokens[8]);

                    imu_msg.orientation.x = 0.0;
                    imu_msg.orientation.y = 0.0;
                    imu_msg.orientation.z = 0.0;
                    imu_msg.orientation.w = 1.0;


                    // Set timestamps and frame IDs
                    imu_msg.header.stamp = this->now();
                    imu_msg.header.frame_id = "imu_link";

                    mag_msg.header.stamp = imu_msg.header.stamp;
                    mag_msg.header.frame_id = "imu_link";

                    // Set covariance based on variance values
                    set_covariance(imu_msg, mag_msg);

                    // Publish messages
                    imu_publisher_->publish(imu_msg);
                    mag_publisher_->publish(mag_msg);

                    RCLCPP_INFO(this->get_logger(), "Published IMU and Magnetometer data");
                } catch (const std::exception &e) {
                    RCLCPP_ERROR(this->get_logger(), "Failed to parse IMU data: %s", e.what());
                }
            }
        }
    }

    std::vector<std::string> split(const std::string &s, char delimiter) {
        std::vector<std::string> tokens;
        std::stringstream ss(s);
        std::string token;
        while (std::getline(ss, token, delimiter)) {
            tokens.push_back(token);
        }
        return tokens;
    }

    void set_covariance(sensor_msgs::msg::Imu &imu_msg, sensor_msgs::msg::MagneticField &mag_msg) {
        // Angular velocity covariance matrix
        std::array<double, 9> angular_velocity_cov = {7.88e-6, 2.64e-6, -3.59e-7, 2.64e-6, 8.91e-5, 3.24e-6, -3.59e-7, 3.24e-6, 1.20e-5};
        std::array<double, 9> linear_acceleration_cov = {9.04e-4, -1.52e-4, 1.45e-2, -1.52e-4, 2.59e-5, -2.43e-3, 1.45e-2, -2.43e-3, 2.32e-1};
        // Indicate that orientation is NOT provided by the sensor
        std::array<double, 9> orientation_cov = {-1, 0, 0, 0, 0, 0, 0, 0, 0};
    
        // Assign covariance matrices
        imu_msg.angular_velocity_covariance = angular_velocity_cov;
        imu_msg.linear_acceleration_covariance = linear_acceleration_cov;
        imu_msg.orientation_covariance = orientation_cov;
    
        // Placeholder magnetometer covariance (if needed)
        std::array<double, 9> mag_cov = {
            0.1322, 0.0183, 0.0131,
            0.0183, 0.0743, 0.0015,
            0.0131, 0.0015, 0.4013
        };
        mag_msg.magnetic_field_covariance = mag_cov;
        
    }
        
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_publisher_;
    rclcpp::Publisher<sensor_msgs::msg::MagneticField>::SharedPtr mag_publisher_;
    drivers::common::IoContext io_context_;
    drivers::serial_driver::SerialPort serial_port_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SerialIMUNode>());
    rclcpp::shutdown();
    return 0;
}
